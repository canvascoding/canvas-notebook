# Canvas Notebook Security Threat Model

## Overview

Canvas Notebook is a self-hosted, container-first Next.js and Node.js application that combines a browser workspace, file management, AI-agent execution, terminal access, automations, integrations, media generation, email, and collaboration. Its primary production surfaces are the App Router HTTP APIs under `app/api/`, the browser UI under `app/`, the custom WebSocket and terminal services under `server/`, persistent state under the configured `DATA` root, the database layer under `app/lib/db/`, and installer, update, backup, and CLI workflows under `install/`, `cli/`, and `scripts/`.

The application intentionally gives authenticated users and agents powerful capabilities, including reading and modifying workspace files, invoking external providers and integrations, installing skills or plugins, and executing tools or terminal commands. Security therefore depends on preserving authentication and object ownership, constraining filesystem paths and executable boundaries, isolating users and workspaces, protecting secrets, and keeping privileged internal services distinct from browser- and network-controlled inputs.

## Threat Model, Trust Boundaries, and Assumptions

### Assets and privileges

- Authentication sessions, bootstrap-admin state, password-reset and account-recovery flows, license state, and role or organization membership.
- Workspace files, uploaded documents and media, public-link content, generated assets, backups, and all other data below the configured `DATA` root.
- SQLite or PostgreSQL records containing users, sessions, conversations, automation definitions, to-dos, integration metadata, and workspace ownership.
- Provider API keys, integration credentials, internal API keys, authentication secrets, OAuth tokens, agent runtime configuration, and files under `/data/secrets/`.
- The terminal service, agent runtime, automation runners, plugin/skill executables, browser automation, MCP tools, and other paths capable of running commands or causing external side effects.
- Host-side installer, updater, systemd, Docker Compose, backup/restore, and management CLI privileges.

### Trust boundaries

- Unauthenticated Internet or local-network clients to public Next.js routes, setup, login, public-link, webhook, health, and license-related endpoints.
- Authenticated browser or mobile clients to user-, organization-, team-, project-, and workspace-scoped APIs.
- Browser cookies and origins to WebSocket authentication, subscription, control, and terminal bridges.
- HTTP/API request data to database queries, filesystem helpers, archive and upload processing, media converters, link-preview/download clients, and rendering pipelines.
- User prompts, uploaded files, stored agent instructions, skills, plugins, MCP responses, and integration data to an agent runtime that can invoke privileged tools.
- Application processes to internal sidecars and Unix/TCP services protected by `CANVAS_INTERNAL_API_KEY` or filesystem permissions.
- The application container to the persistent `/data` mount and, in installer or CLI flows, from container/application state to host Docker and systemd control.
- The application to external AI, OAuth, email, media, license, webhook, and integration providers.
- One user, organization, team, project, workspace, session, or public share to another tenant or object owner.

### Input classification and assumptions

- Treat request paths, query strings, headers, cookies, multipart uploads, JSON bodies, WebSocket messages, webhook payloads, public-link identifiers, file names, archive member names, URLs, provider responses, and imported or restored data as attacker-controlled at their respective boundaries.
- Treat stored prompts, workspace files, agent instructions, skill/plugin manifests, MCP output, email content, and integration data as untrusted data even when an authenticated user supplied them.
- Treat environment variables, Compose files, installer options, server configuration, and administrator-authored policies as operator-controlled; they are not normally remote attacker input, but unsafe defaults or validation gaps can expose production deployments.
- Treat repository scripts, build metadata, and development tooling as developer-controlled unless a remote artifact, pull request, package source, update channel, or imported data crosses into them.
- Authentication alone does not authorize access to an arbitrary object. Every user-, organization-, workspace-, session-, media-, file-, automation-, and integration-scoped operation must enforce the corresponding ownership or membership check.
- Intentional terminal and agent code execution is in scope when a lower-trust actor can cross its intended authentication, authorization, path, user, or tool-policy boundary; merely allowing an authorized owner to run their own commands is expected behavior.

## Attack Surface, Mitigations, and Attacker Stories

### Primary attack surfaces

- Authentication, setup, bootstrap, account, mobile, license, session, user, organization, team, project, and public-link routes.
- File read/write, upload, download, preview, conversion, archive extraction, backup, restore, migration, export, and workspace path-resolution helpers.
- WebSocket chat/session subscriptions, origin validation, terminal-session ownership, internal service authentication, and message-size or resource controls.
- Agent prompts and attachments, automation/webhook triggers, skill/plugin installation and execution, MCP tools, browser automation, and integration actions.
- Server-side URL fetches for link previews, downloads, callbacks, webhooks, OAuth, model/media providers, and license activation.
- Markdown/HTML/media rendering, document conversion, downloadable content, and any template or browser context that can turn stored data into active content.
- SQLite/PostgreSQL query construction, migrations, object binding, and cross-tenant selectors.
- Installer/update scripts, container images, dependency acquisition, backup/restore archives, CLI privilege transitions, and secrets-file handling.

### Existing mitigations and controls to preserve

- Better Auth sessions, trusted-origin handling, route-local session checks, WebSocket authentication, and internal API keys provide authentication boundaries when consistently applied.
- Ownership and workspace-scoping helpers, scoped data paths, and organization/team/project identifiers are intended to separate users and tenants.
- Container deployment, a dedicated persistent data root, non-public internal services, and host-side management boundaries can limit blast radius when defaults and mounts are secure.
- Focused tests cover rate limiting, scoped runtime paths, origin policy, zip extraction, restore validation, backup, MCP/OAuth scoping, plugin/skill runtime behavior, and many user/workspace boundaries; these are valuable regression controls but do not replace source-level verification.
- Security policy requires concrete exploitable paths and treats missing hardening without impact, unsupported releases, and traffic-volume-only denial of service as out of scope.

### Realistic attacker stories

- An unauthenticated client abuses setup, public, webhook, mobile, or authentication routes to create an account, recover or bind another identity, access protected data, or trigger privileged work.
- An authenticated low-privilege user substitutes object, workspace, organization, session, output, file, or integration identifiers to read or modify another user's data.
- A crafted path, upload, archive, backup, or restore payload escapes its intended storage root, overwrites trusted configuration, exposes secrets, or plants active content.
- A crafted URL or redirect causes the server to access internal services, cloud metadata, localhost-only control planes, or file-backed resources.
- Malicious workspace content, email, MCP output, plugin metadata, or agent instructions induce a privileged agent or automation to exfiltrate secrets or invoke a tool outside the user's granted scope.
- A cross-site page exploits weak origin, CSRF, WebSocket, or content-rendering controls to act with a victim's browser session.
- A client reaches the terminal, internal service, installer/update, backup/restore, or command runner without the intended authentication, ownership, argument validation, or privilege separation.
- A malicious or substituted update, package, container, plugin, skill, or backup artifact crosses the trusted supply-chain boundary and executes with application or host privileges.

Out-of-scope or normally lower-value stories include attacks requiring existing host root or equivalent command execution without a privilege delta, self-XSS requiring an administrator to paste code into their own terminal, dependency advisories without a reachable application path, unsupported old releases, and traffic-volume-only denial of service.

## Severity Calibration (Critical, High, Medium, Low)

### Critical

- Unauthenticated or near-unauthenticated remote command execution through an API, WebSocket, upload, agent, terminal, plugin, or conversion path.
- Broad authentication bypass, cross-tenant administrative compromise, or direct theft of authentication, provider, signing, or control-plane credentials.
- Arbitrary file write into executable, startup, trusted configuration, or update paths with realistic persistence or host/container compromise.
- Supply-chain or update-channel compromise that predictably delivers attacker code to maintained deployments.

### High

- Narrower but realistic authorization bypass exposing meaningful workspace data, secrets, or privileged actions across users or tenants.
- Arbitrary file read/write, dangerous stored active content, exploitable archive extraction, or SSRF reaching meaningful internal or metadata targets.
- CSRF or WebSocket origin failures enabling important credential, permission, billing, integration, automation, or command actions.
- Plugin, skill, MCP, deserialization, template, or interpreter abuse with clearly reachable dangerous primitives but incomplete proof of full compromise.

### Medium

- Authenticated same-tenant boundary breaks with material but constrained confidentiality or integrity impact.
- Internal-network or feature-gated SSRF, command, file, or automation paths with realistic but limited preconditions.
- Sensitive-data exposure or security-control bypass that requires victim interaction, a non-default feature, or a constrained role and does not yield broad compromise.
- Resource exhaustion that a remote or low-privilege actor can repeatedly trigger and that materially affects shared service availability.

### Low

- Limited information exposure, constrained open redirects, low-impact CSRF, or weaknesses affecting only the attacker's own data.
- Localhost-only, operator-only, development-only, or opt-in dangerous behavior without a meaningful lower-privilege boundary crossing.
- Defense-in-depth gaps and minor robustness issues with a concrete but narrowly scoped security consequence.

Repository: target_sha256_adf3597ca7dd0df024ba0592e6eee123616bef77fb6ae1f5965f11b984a4cffa
Version: codex-security-snapshot/v1:sha256:d9f142ebfecbc76edbcccec191dd7777750972c32653162dc5b665a2c4d852d9
