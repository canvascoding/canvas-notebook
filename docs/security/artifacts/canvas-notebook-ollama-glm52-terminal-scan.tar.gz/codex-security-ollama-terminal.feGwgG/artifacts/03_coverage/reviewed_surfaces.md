# Reviewed Surfaces

| Surface | Risk Area | Outcome | Notes |
| --- | --- | --- | --- |
| Terminal session operation authorization | Authorization bypass / IDOR on user-keyed terminal sessions | reported | input, stream, resize, and terminate routes authenticate but do not verify session ownership; reported as finding. |
| Container runtime privilege boundary | Privilege escalation via sudoers NOPASSWD:ALL | reported | Dockerfile grants APP_USER passwordless sudo to ALL; reported as finding. |
| Terminal cwd path containment | Path traversal / symlink escape | no_issue_found | resolveTerminalWorkspaceCwd enforces absolute path, NUL rejection, isPathWithin, and realpath of deepest existing ancestor + final path; cwd is server-derived and permission-gated. Ruled out. |
| Terminal service socket permissions | Permissive local socket | rejected | Socket chmod 0o666 is token-protected (randomBytes(32) default); no concrete bypass shown; hardening-only per SECURITY.md scope. |
| Terminal environment secret filtering | Secret exposure via incomplete denylist | rejected | filterTerminalEnv denylist is reasonably comprehensive; no specific leaked deployment secret demonstrated in scope. |
| Workspace permission resolution | Workspace role/permission logic | no_issue_found | resolveWorkspacePermissions and assertWorkspacePermission reviewed; logic is sound and role/type gated. No credible issue survived. |
