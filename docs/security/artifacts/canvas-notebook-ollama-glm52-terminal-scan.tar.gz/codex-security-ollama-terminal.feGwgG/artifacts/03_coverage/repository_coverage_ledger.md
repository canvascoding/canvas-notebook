# Repository Coverage Ledger

Scoped-path scan. Every in-scope file was reviewed in full and every candidate decided.

## In-Scope Files

- Dockerfile
- app/api/terminal/[id]/input/route.ts
- app/api/terminal/[id]/resize/route.ts
- app/api/terminal/[id]/route.ts
- app/api/terminal/[id]/stream/route.ts
- app/api/terminal/create/route.ts
- app/api/terminal/kill/route.ts
- app/lib/workspaces/permissions.ts
- server/terminal-service.ts

## Candidate Ledger

| Candidate ID | CWE | Disposition | Summary |
| --- | --- | --- | --- |
| candidate-8c654037cc841dd2 | CWE-200 | suppressed | Terminal environment filtering uses a denylist, so deployment env vars with non-standard secret names can reach the PTY. |
| candidate-2425ca769bea6062 | CWE-22 | not_applicable | Terminal cwd is resolved and confined before spawning a shell; candidate path-traversal via symlink escape. |
| candidate-9f2b5e44a2757af1 | CWE-269, CWE-732 | reportable | The runtime Dockerfile grants the non-root APP_USER passwordless sudo to ALL (NOPASSWD:ALL), trivially undoing the USER node isolation it sets later. |
| candidate-91850c1ade604100 | CWE-639, CWE-862 | reportable | Terminal session operations (input, stream, resize, terminate) only verify the caller is authenticated, not that the caller owns the session identified by the [id] path parameter. Any logged-in user can inject commands into, read output from, resize, or kill another user terminal session by supplying its sessionId. |
| candidate-9ba4702a81653f66 | CWE-732 | suppressed | Terminal service Unix socket is chmod 0o666 so any local process can attempt to connect. |

## Decisions

### candidate-8c654037cc841dd2

- Summary: Terminal environment filtering uses a denylist, so deployment env vars with non-standard secret names can reach the PTY.
- Validation: suppressed (medium) - static review of env filtering
- Evidence: server/terminal-service.ts:124-135 denylist; 240-252 env passed to spawnPty.
- Counterevidence/proof gap: No concrete deployment secret with a non-matching name is identified; impact is speculative.

### candidate-2425ca769bea6062

- Summary: Terminal cwd is resolved and confined before spawning a shell; candidate path-traversal via symlink escape.
- Validation: not_applicable (high) - static source trace of cwd resolution
- Evidence: server/terminal-service.ts:198-219 deepestExistingTerminalPath + assertTerminalPathResolvesWithinAllowedRoots; create/route.ts:34-51 resolveAgentSessionWorkspaceForUser enforces workspace permissions.
- Counterevidence/proof gap: A TOCTOU between realpath check and mkdir/spawn would require local filesystem race access; no attacker-controlled raw path reaches this function.

### candidate-9f2b5e44a2757af1

- Summary: The runtime Dockerfile grants the non-root APP_USER passwordless sudo to ALL (NOPASSWD:ALL), trivially undoing the USER node isolation it sets later.
- Validation: reportable (high) - static review of Dockerfile runtime stage
- Evidence: Dockerfile:163 RUN echo "${APP_USER} ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/${APP_USER} && chmod 0440 ...; Dockerfile:247 USER ${APP_USER}. The in-scope browser terminal runs an interactive shell as this user.
- Counterevidence/proof gap: No evidence the rule is later removed or restricted; whether specific startup scripts require sudo was not enumerated, but NOPASSWD:ALL is broader than any specific need.
- Attack path: reportable; severity=medium; impact=high; likelihood=high
- Severity rationale: Root inside the container gives full access to all /data workspaces, SQLite data, and secrets across tenants, but does not by itself escape the container to the host. Severity would rise to high if multi-tenant isolation is a supported guarantee or if container escape is reachable; it would lower to low if the deployment model is strictly single-user single-owner.

### candidate-91850c1ade604100

- Summary: Terminal session operations (input, stream, resize, terminate) only verify the caller is authenticated, not that the caller owns the session identified by the [id] path parameter. Any logged-in user can inject commands into, read output from, resize, or kill another user terminal session by supplying its sessionId.
- Validation: reportable (high) - static source trace across API routes and terminal-service handler
- Evidence: input/route.ts:14-36 authenticates then forwards [id] to sendInput; stream/route.ts:14-28 authenticates then attaches by [id]; resize/route.ts and route.ts (DELETE) do the same. server/terminal-service.ts:606-613 (input), 594 (attach), 618 (resize), 630 (terminate) check only authenticatedClients.has(client). handleInput:541-548 writes to session.pty.write with no owner match.
- Counterevidence/proof gap: Session IDs are random UUIDs in the default frontend flow (generateRandomId -> crypto.randomUUID), so blind guessing of a victim sessionId is infeasible. Exploitation requires the attacker to learn a target sessionId via disclosure (logs, shared workspace, referrer) rather than enumeration.
- Attack path: reportable; severity=medium; impact=high; likelihood=low
- Severity rationale: Impact is high (arbitrary command execution and output disclosure in another user workspace context, crossing workspace/tenant boundaries), but likelihood is low because exploitation depends on obtaining a random UUID sessionId rather than pure authentication. Concrete evidence that would raise severity: any path that discloses sessionIds to other users; evidence that would lower it: a server-side ownership check currently missed in this in-scope review.

### candidate-9ba4702a81653f66

- Summary: Terminal service Unix socket is chmod 0o666 so any local process can attempt to connect.
- Validation: suppressed (medium) - static review of server setup
- Evidence: server/terminal-service.ts:736-740 chmod 0o666; AUTH_TOKEN default randomBytes(32).
- Counterevidence/proof gap: If CANVAS_TERMINAL_TOKEN is configured to a weak value, risk increases, but that is an operator config issue not shown in code.
