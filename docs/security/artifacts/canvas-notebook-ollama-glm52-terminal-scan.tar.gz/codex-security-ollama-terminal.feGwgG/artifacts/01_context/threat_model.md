# Threat Model - Terminal & Workspace Permission Surface

## Summary
Canvas Notebook exposes an in-browser terminal backed by a separate
server/terminal-service.ts process (Unix socket in Docker, loopback TCP in
dev) plus Next.js API routes under app/api/terminal/**. Workspace access is
gated by app/lib/workspaces/permissions.ts. The runtime container is built
from Dockerfile. This threat model covers the terminal command-execution
surface, session ownership/authorization, workspace path containment, and
container privilege boundaries.

## Assets
- Workspace files under /data/workspace and /data/workspaces (per-user and shared/team/organization/project workspaces).
- Terminal sessions: PTY processes running an interactive shell inside a workspace root, including their buffered output and live stream.
- Deployment secrets and integration API keys held in the service process environment.
- The container OS boundary: the non-root node runtime user versus root.

## Trust Boundaries
- HTTP user to Next.js API route: authenticated browser users (via auth.api.getSession) reach /api/terminal/**. Not every authenticated user owns every terminal session or workspace.
- Next.js server to terminal service: a single shared CANVAS_TERMINAL_TOKEN authenticates the Next.js process to the terminal service over a Unix socket (chmod 0o666) or loopback TCP. The service trusts the Next.js layer to enforce per-user authorization.
- Terminal PTY to filesystem: a shell runs inside a resolved workspace cwd; it inherits a filtered environment and can execute arbitrary commands as the node OS user.
- Container user to root: Dockerfile provisions the runtime as USER node but also installs a sudoers rule.

## Attacker Capabilities
- Authenticated low-privilege user with their own account and workspace access.
- Ability to call any /api/terminal/** route with a chosen [id] path segment and JSON body.
- Ability to create a terminal session in a workspace they can read/write.
- Local co-tenant access to the same container/OS user as other users in multi-user deployments.

## Security Objectives
- A user may only send input to, stream output from, resize, or terminate terminal sessions they own.
- Terminal shells must stay confined to managed workspace directories (no path traversal or symlink escape).
- Workspace permission checks must gate every privileged terminal action, not just creation.
- Deployment secrets must not leak into terminal environments.
- The non-root container user must not be trivially escalatable to root.

## Assumptions
- Multi-user/multi-workspace deployments are supported (personal, team, organization, project workspaces with distinct roles).
- Session IDs are generated client-side as random UUIDs in the default frontend flow, but are user-controlled keys at the API boundary.
- The terminal service is reachable only from the Next.js process in production (Unix socket inside the container).

Repository: target_sha256_adf3597ca7dd0df024ba0592e6eee123616bef77fb6ae1f5965f11b984a4cffa
Version: b18eab5234e84d699a105acbad979714a87a7f70
