# Reviewed Surfaces

Scope: 78 in-scope files across app/api/files, app/api/public, app/lib/files, server/collaboration-server.ts, and server/excalidraw-collaboration/server.ts. Validation: compact standard-scan static source trace.

| Surface | Risk Area | Outcome | Notes |
| --- | --- | --- | --- |
| File API path traversal and containment | path-traversal | No issue found | All file APIs resolve through path-guard with realpath containment; traversal, absolute, and null-byte paths are rejected. |
| Archive extraction | archive-extraction | No issue found | extractWorkspaceZip normalizes entry paths, rejects traversal, and enforces archive, extracted, and entry-count limits with no-overwrite writes. |
| File API authorization and workspace scoping | authorization | No issue found | Workspace file routes use requireRequestWorkspace with canRead or canWrite and per-workspace permission checks. |
| Upload-serving routes (/api/files/[id]) | xss-and-access-control | Reported | Stored XSS via HTML attachments served as text/html, and missing ownership checks allowing cross-user reads by file id. |
| Excalidraw asset upload and download | xss | Reported | Stored XSS via SVG assets whose active content bypasses the 8192-byte sanitizer and is served as image/svg+xml. |
| Collaboration WebSocket servers | collaboration-message-validation | No issue found | Both servers verify tickets, sessions, workspace membership, document scope, origin, message size, and rate limits. |
| PDF and Marp export pipelines | command-injection-ssrf | No issue found | Marp CLI and ffmpeg are spawned with array arguments (no shell); render origins are constrained to 127.0.0.1 with a validated port. |
| File preview and studio media access | authorization | Needs follow-up | The user-uploads/studio-references preview branch omits the canReadStudioMediaPath check present on sibling studio branches; deferred pending the out-of-scope studio trust model. |
| Public brand logo | xss | No issue found | Serves an admin-configured logo with nosniff and a fixed organization identity; no user-controlled path or content type. |
| File library utilities | path-handling | No issue found | path-utils, upload-paths, collaboration-policy, and operation-flows normalize paths and use parameterized SQL; traversal is blocked downstream by path-guard. |
