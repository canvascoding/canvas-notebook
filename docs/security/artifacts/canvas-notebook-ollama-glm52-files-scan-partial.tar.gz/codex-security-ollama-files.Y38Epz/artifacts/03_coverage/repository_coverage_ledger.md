# Repository Coverage Ledger

Scan ID: 847fdfd2-96b0-4d76-9b82-c08cfbfaa1e7
Target: canvasstudios-notebook
Mode: scoped_path | Inventory: scoped_path | Completeness: partial

## Checked Surfaces

- **File API path traversal and containment** — no_issue_found. path-guard realpath containment rejects traversal, absolute, and null-byte paths across read, write, copy, rename, delete, tree, download, and extract routes.
- **Archive extraction** — no_issue_found. extractWorkspaceZip normalizes entry paths, rejects traversal/absolute/null, and caps archive (100 MB), extracted (500 MB), and entry count (2000) with no-overwrite writes.
- **File API authorization** — no_issue_found. Workspace file routes use requireRequestWorkspace with canRead or canWrite and per-workspace permission checks; locks force-release is restricted to managers.
- **Upload-serving routes (/api/files/[id], /api/files/[id]/preview)** — reported. Stored XSS via HTML attachments served as text/html (candidate html-attachment-text-html), and missing ownership checks allowing cross-user reads by file id (candidate upload-id-no-ownership-check).
- **Excalidraw asset upload and download** — reported. Stored XSS via SVG assets whose active content bypasses the 8192-byte sanitizer and is served as image/svg+xml (candidate svg-active-content-after-8192).
- **Collaboration WebSocket servers** — no_issue_found. Both servers verify collaboration tickets, sessions, workspace membership, document scope/generation, origin, message size (1 MiB), and rate limits; rooms are keyed by documentId and broadcasts are scoped.
- **PDF and Marp export pipelines** — no_issue_found. Marp CLI and ffmpeg are spawned with array arguments (no shell injection); html-pdf render origin is constrained to 127.0.0.1 with a validated port.
- **File preview and studio media access** — needs_follow_up (deferred). The user-uploads/studio-references preview branch omits canReadStudioMediaPath; deferred pending the out-of-scope studio trust model (candidate studio-ref-no-media-access-check).
- **Public brand logo** — no_issue_found. Serves an admin-configured logo with nosniff and a fixed organization identity; no user-controlled path or content type.
- **File library utilities** — no_issue_found. path-utils, upload-paths, collaboration-policy, and operation-flows normalize paths and use parameterized SQL; traversal is blocked downstream by path-guard.

## Deferred

- candidate-437996a15bd811cc (studio-ref-no-media-access-check): Studio reference upload access check depends on the out-of-scope studio trust model; needs follow-up with the studio module owner.

## Open Questions

- Are user-uploads file IDs intended to act as unguessable capability URLs, or should /api/files/[id] enforce per-owner authorization?
- Does the studio reference upload path intend workspace-public reads, or should /api/files/preview enforce canReadStudioMediaPath for user-uploads/studio-references?
