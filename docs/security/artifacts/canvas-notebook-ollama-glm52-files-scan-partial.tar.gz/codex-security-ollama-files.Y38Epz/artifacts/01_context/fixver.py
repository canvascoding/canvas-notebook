import os
p=os.environ["TM"]
lines=open(p).read().splitlines()
lines=[l if not l.startswith("Version:") else "Version: bfcdbd6c3d2739df6703a2c4a15312caaa8b2578" for l in lines]
open(p,"w").write("\n".join(lines)+"\n")
