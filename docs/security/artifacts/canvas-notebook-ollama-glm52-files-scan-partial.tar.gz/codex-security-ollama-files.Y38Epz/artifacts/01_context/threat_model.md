# Canvas Notebook — Repository Threat Model

## Product Overview

Canvas Notebook is a self-hosted, Next.js (App Router) notebook/workspace application. It stores user workspace files, SQLite/postgres metadata, and secrets under a configurable data root (`DATA`, default `./data`). It ships as a container image (`ghcr.io/canvascoding/canvas-notebook`) managed by a host "Canvas Agent" over a WebSocket tunnel to a remote Control Plane. The product exposes a web UI and a REST API (`app/api/*`) plus two WebSocket collaboration servers (`server/collaboration-server.ts`, `server/excalidraw-collaboration/server.ts`).

## Primary Surfaces And Trust Boundaries

- **HTTP API (`app/api/...`)**: Next.js route handlers. Authenticated via `requireRequestWorkspace` (session + workspace permission checks). Trust boundary: any authenticated user of a workspace is a potential attacker for cross-workspace or path-boundary issues; unauthenticated callers must be rejected. Workspace selection via `x-workspace-id` header or `workspaceId` query param is attacker-controlled.
- **Filesystem workspace (`app/lib/filesystem`, `app/lib/files`)**: All file operations resolve to a per-workspace root through `path-guard` (`resolveWorkspacePath`/`resolveExistingWorkspacePath`/`resolveWritableWorkspacePath`). Invariant: user-supplied paths must never escape the workspace root. Symlink resolution via `realpath` + `assertWithinBase` is the primary control.
- **Collaboration WebSocket servers**: `server/collaboration-server.ts` and `server/excalidraw-collaboration/server.ts` accept WebSocket connections, authenticate sessions, and broadcast document/operation updates. Trust boundary: a connected client can send arbitrary messages; the server must validate origin, session, workspace membership, and message shape.
- **Public brand API (`app/api/public/brand/logo`)**: unauthenticated surface for branding assets; must not expose arbitrary filesystem reads.
- **Secrets / env**: Integration secrets live in `/data/secrets/*.env` and are accessed via `/api/integrations/env`; they must never be exposed through file APIs.

## Assets

- Workspace file contents (read/write/create/delete/rename/copy/extract).
- SQLite/postgres metadata (revisions, locks, collaboration state, trash).
- Session cookies and workspace membership/permissions.
- Integration secrets and API keys under `/data/secrets`.
- Server process integrity (no arbitrary command execution via file/collab paths).

## Attacker Capabilities

- Authenticated workspace member sending crafted HTTP requests with arbitrary `path`, file payloads, archive contents, and `workspaceId` values.
- WebSocket client sending malformed/out-of-sequence collaboration messages, spoofed origins, or messages for other sessions/workspaces.
- Unauthenticated caller reaching public or under-protected endpoints.
- Attacker-controlled archive contents (zip extraction) and uploaded file names.

## Security Objectives

- Prevent path traversal / arbitrary file read or write outside the workspace root.
- Enforce authentication and per-workspace authorization on every mutating and read endpoint; no cross-workspace access.
- Validate collaboration messages: origin, session, workspace, operation ordering, and replay; prevent cross-session/cross-workspace broadcast leaks.
- Prevent SSRF, command injection, and unsafe deserialization/parsing.
- Prevent XSS via file content served to browsers (previews, downloads, exports).
- Prevent resource exhaustion (unbounded archives, large files, zip bombs).

## Assumptions

- `path-guard` is the canonical containment layer; routes that bypass it or join raw user paths to the data root are suspicious.
- The data root and workspace roots are the only legitimate filesystem scope.
- Collaboration servers run alongside the Next.js server and share session/auth semantics; transport is WebSocket.
- Self-hosted single-tenant deployments still treat authenticated users as the trust boundary for path-confidentiality and integrity issues.

## Repository-Wide Failure Modes Of Most Concern

- Path traversal in file APIs (read/write/copy/rename/extract/tree/download).
- Zip/archive extraction escaping the workspace root or causing resource exhaustion.
- Authorization bypass / cross-workspace file access via spoofed `workspaceId`.
- Collaboration WebSocket message validation gaps (origin, session, replay, cross-workspace broadcast, denial-of-service via unbounded buffers).
- SSRF in export/render endpoints that fetch internal URLs.
- XSS/content-type issues in file preview/download/export responses.
- Command injection in PDF/render pipelines.

Repository: target_sha256_adf3597ca7dd0df024ba0592e6eee123616bef77fb6ae1f5965f11b984a4cffa
Version: bfcdbd6c3d2739df6703a2c4a15312caaa8b2578
