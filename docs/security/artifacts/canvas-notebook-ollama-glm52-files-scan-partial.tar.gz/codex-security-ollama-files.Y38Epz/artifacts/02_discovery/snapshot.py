import hashlib, os
root=os.getcwd()
files=[l.strip() for l in open(os.environ["SCOPE"]) if l.strip()]
entries=[]
for rel in files:
    p=os.path.join(root, rel)
    try:
        h=hashlib.sha256(open(p,"rb").read()).hexdigest()
    except Exception:
        h="missing"
    entries.append((rel, h))
entries.sort()
data="\n".join(rel+"\x00"+h for rel,h in entries)
print("codex-security-snapshot/v1:sha256:"+hashlib.sha256(data.encode()).hexdigest())
