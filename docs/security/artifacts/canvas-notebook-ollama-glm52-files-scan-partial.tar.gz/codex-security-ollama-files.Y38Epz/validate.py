import json, os, hashlib, re
SD=os.environ["SD"]; SID=os.environ["SID"]; TID=os.environ["TID"]
def load(n): return json.load(open(os.path.join(SD,n)))
ALGO="codex-security/v1"
def sha(s): return hashlib.sha256(s.encode()).hexdigest()
def fp(rid,a,i): return ALGO+":sha256:"+sha("\0".join((ALGO,TID,rid,a,i)))
def sid(p,*x): return p+"_"+sha(chr(0).join(x))[:24]
SLUG=re.compile(r"^[a-z0-9][a-z0-9._/-]*$")
errs=[]
f=load("findings.json")
if not (f["documentType"]=="codex-security.findings" and f["schemaVersion"]=="1.0" and f["scanId"]==SID): errs.append("findings header")
if not (isinstance(f["findings"],list) and len(f["findings"])==3): errs.append("findings count")
for fd in f["findings"]:
    rid=fd["ruleId"]; anc=fd["identity"]["anchor"]; inst=fd["identity"].get("instance","")
    if not SLUG.match(rid): errs.append("ruleId slug "+rid)
    if not SLUG.match(anc): errs.append("anchor slug "+anc)
    if inst and not SLUG.match(inst): errs.append("instance slug "+inst)
    exp=fp(rid,anc,inst)
    if fd["fingerprints"]["primary"]!=exp: errs.append("fingerprint "+rid)
    if fd["findingId"]!=sid("csf",exp): errs.append("findingId "+rid)
    if fd["occurrenceId"]!=sid("occ",SID,exp): errs.append("occurrenceId "+rid)
    if not re.match(r"^csf_[a-f0-9]{24}$",fd["findingId"]): errs.append("findingId fmt "+rid)
    if not re.match(r"^occ_[a-f0-9]{24}$",fd["occurrenceId"]): errs.append("occurrenceId fmt "+rid)
    for loc in fd["locations"]:
        if not isinstance(loc["startLine"],int) or loc["startLine"]<1: errs.append("loc start "+rid)
    for ce in fd.get("codeEvidence",[]):
        if not ce.get("code"): errs.append("empty codeEvidence "+ce["id"])
c=load("coverage.json")
if not (c["documentType"]=="codex-security.coverage" and c["schemaVersion"]=="1.0" and c["scanId"]==SID): errs.append("coverage header")
if c["mode"]!="scoped_path" or c["inventoryStrategy"]!="scoped_path": errs.append("coverage mode")
if c["completeness"]!="partial": errs.append("completeness")
if len(c["deferred"])!=1: errs.append("deferred count")
nf=[s for s in c["surfaces"] if s["disposition"]=="needs_follow_up"]
if len(nf)!=1: errs.append("needs_follow_up surface count")
rep=[s for s in c["surfaces"] if s["disposition"]=="reported"]
if len(rep)!=2: errs.append("reported surface count "+str(len(rep)))
m=load("scan-manifest.json")
sc=m["scan"]
if not (m["documentType"]=="codex-security.scan-manifest" and m["schemaVersion"]=="1.0"): errs.append("manifest header")
if sc["id"]!=SID: errs.append("scan id")
if sc["producer"]["name"]!="codex-security-plugin": errs.append("producer name")
if sc["status"]!="completed": errs.append("status")
if sc["target"]["targetId"]!=TID: errs.append("targetId")
if sc["target"]["displayName"]!=os.environ["DN"]: errs.append("displayName")
if "sealedAt" in sc: errs.append("sealedAt should be absent (unsealed)")
if "artifacts" in sc: errs.append("artifacts should be absent (unsealed)")
for k in ["id","producer","status","startedAt","completedAt","target","scope","coverageRef","findingsRef"]:
    if k not in sc: errs.append("missing scan."+k)
if "snapshotDigest" not in sc["target"]: errs.append("missing snapshotDigest")
if "threatModel" not in sc: errs.append("missing threatModel")
print("VALIDATION ERRORS:" if errs else "ALL CHECKS PASSED")
for e in errs: print(" -",e)
