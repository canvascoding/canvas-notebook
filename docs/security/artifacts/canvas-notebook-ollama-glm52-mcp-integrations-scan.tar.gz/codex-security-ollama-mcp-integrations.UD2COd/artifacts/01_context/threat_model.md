# Threat Model — canvasstudios-notebook (MCP & Integrations scoped scan)

## Scope
Single-pass standard security audit of the MCP integration layer and Studio
integrations services under app/api/integrations, app/lib/integrations, and
app/lib/mcp (50 in-scope files). The repository is a Next.js multi-tenant
application with organizations, workspaces, MCP server proxying, OAuth, env/secret
management, and media generation integrations (Gemini/Veo, OpenAI, KIE/Seedance,
Brave Search, Groq).

## Assets
- Per-user / per-organization secrets and API keys (env files, OAuth tokens).
- MCP server configuration and OAuth client credentials/state.
- Studio media assets, outputs, and edits (per-workspace files).
- Shared legacy workspace filesystem root (data/workspace).
- Control-plane instance token (CANVAS_INSTANCE_TOKEN).

## Trust Boundaries
- HTTP request to API route (authenticated session, optional org-admin / workspace canWrite).
- User-controlled request bodies (paths, URLs, MCP config JSON, prompts).
- Server to external provider APIs (Gemini, OpenAI, KIE, Brave, Groq) and MCP servers.
- Server to control plane (managed media / managed brave search).
- Per-workspace file storage vs. shared legacy workspace root.

## Attacker Capabilities
- Authenticated low-privilege tenant user with canWrite to their own workspace.
- Control request bodies to Studio, MCP, and env endpoints.
- Supply media reference paths/URLs and MCP server configs (when permitted).

## Security Objectives
- Enforce workspace/tenant isolation for all file reads and writes.
- Prevent SSRF to private/internal networks from server-side fetches.
- Prevent path traversal outside intended storage roots.
- Protect secrets at rest and in transit; never leak credentials cross-tenant.
- Validate MCP config before use; gate stdio execution.

## Assumptions
- safe-paths (resolvePathInside/requirePathInside) and safe-external-fetch are
  trusted containment/SSRF primitives (reviewed as supporting evidence).
- Multi-tenant deployments share the legacy data/workspace root across users
  (getWorkspacePath returns a single non-isolated base directory).

Repository: target_sha256_adf3597ca7dd0df024ba0592e6eee123616bef77fb6ae1f5965f11b984a4cffa
Version: b18eab5234e84d699a105acbad979714a87a7f70
