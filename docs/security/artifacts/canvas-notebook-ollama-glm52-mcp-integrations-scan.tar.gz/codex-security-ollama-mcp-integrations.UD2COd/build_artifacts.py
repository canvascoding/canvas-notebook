import json, os, hashlib
REPO=os.environ['CODEX_SECURITY_REPOSITORY']
SCAN=os.environ['CODEX_SECURITY_SCAN_DIR']
SCAN_ID=os.environ['CODEX_SECURITY_SCAN_ID']
TARGET_ID=os.environ['CODEX_SECURITY_TARGET_ID']
DISPLAY=os.environ['CODEX_SECURITY_TARGET_DISPLAY_NAME']
REV='b18eab5234e84d699a105acbad979714a87a7f70'
REMOTE='https://github.com/canvascoding/canvas-notebook.git'
SNAP='codex-security-snapshot/v1:sha256:69fa7f0b619557d0b9fdea00255b0d5802b05c68cb0753b44b46549d39d09e35'

def lines(rel, a, b):
    p=os.path.join(REPO, rel)
    with open(p, encoding='utf-8') as f:
        all_lines=f.read().splitlines()
    return '\n'.join(all_lines[a-1:b])

def ce(i, label, rel, a, b, role, expl):
    return {'id':i,'label':label,'path':rel,'startLine':a,'endLine':b,'language':'typescript','role':role,'code':lines(rel,a,b),'explanation':expl}

codeEvidence=[
  ce('save-route','Save route forwards user body to service','app/api/studio/aspect-ratio/save/route.ts',40,43,'entrypoint','The POST handler passes the full user-controlled body and only the caller own workspace scope into saveAspectRatioEdit; workspaceOptions is null for overwrite_original.'),
  ce('service-sig','Buffer comes from caller own edit file','app/lib/integrations/studio-aspect-ratio-service.ts',588,593,'user_input','getEditRelativePath validates previewPath against the caller workspace edits dir, so the written buffer is a sharp re-encoded image the caller controls.'),
  ce('overwrite-branch','Scope guard only covers studio paths','app/lib/integrations/studio-aspect-ratio-service.ts',610,625,'root_control','canReadStudioMediaPath is invoked only when sourcePath starts with studio/. For other kinds the workspace readability check is skipped, classifyMediaReference is called with no scope, and fs.writeFile overwrites ref.absolutePath.'),
  ce('classify','Unscoped classify resolves to shared root','app/lib/integrations/media-reference-resolver.ts',300,311,'propagation','Without a userId, workspace-relative paths resolve via resolveValidatedWorkspaceRelativePath against the shared workspace root instead of the caller workspace.'),
  ce('shared-root','Workspace root is shared and non-isolated','app/lib/utils/workspace-manager.ts',21,25,'sink','getWorkspacePath ignores the session and returns one base directory shared across all users, so the resolved write target is not confined to the caller tenant.'),
]

finding={
  'findingId':'csf_c07922a601bceadd42e13d35',
  'occurrenceId':'occ_81e3c87b639e7ad7fb2ae724',
  'ruleId':'path-traversal.aspect-ratio-overwrite',
  'identity':{'anchor':'overwrite-original-unscoped-workspace-write'},
  'fingerprints':{'algorithm':'codex-security/v1','primary':'codex-security/v1:sha256:174bfa017297b37d6086cfdd65a7ce1e7dac786e14cd63e8e798a96b9ae20b9d'},
  'title':'Cross-tenant file overwrite via unscoped source path in aspect-ratio overwrite_original',
  'summary':'saveAspectRatioEdit enforces workspace-scoped readability only for studio/ source paths. For workspace_relative, workspace_absolute, or user_upload source paths the check is skipped and classifyMediaReference is called without a user/workspace context, resolving the target against the shared legacy workspace root; fs.writeFile then overwrites that file with attacker-controlled image content, enabling cross-user/cross-tenant file overwrite.',
  'severity':{'level':'high','score':7.6,'scoringSystem':'CVSS:3.1','rationale':'Authenticated low-privilege tenant user can overwrite files belonging to other users/workspaces in the shared workspace root, breaking cross-tenant integrity and availability. Path traversal above the shared root is blocked and written bytes are a re-encoded image, which bounds the impact.','changeConditions':'Severity rises if arbitrary non-image bytes can be written or the write escapes the workspace root; it drops to medium if production deployments keep no victim files in the shared legacy root.'},
  'confidence':{'level':'high','rationale':'Static source trace confirms the conditional guard, the unscoped classifyMediaReference call, the shared non-isolated workspace root, and that the save route forwards the full body with only caller-workspace canWrite.'},
  'taxonomy':{'category':'path-traversal','cwe':['CWE-22','CWE-73']},
  'locations':[
    {'path':'app/lib/integrations/studio-aspect-ratio-service.ts','startLine':617,'endLine':618,'role':'root_control'},
    {'path':'app/lib/integrations/studio-aspect-ratio-service.ts','startLine':620,'endLine':621,'role':'source'},
    {'path':'app/lib/integrations/studio-aspect-ratio-service.ts','startLine':624,'endLine':624,'role':'sink'},
    {'path':'app/api/studio/aspect-ratio/save/route.ts','startLine':40,'endLine':43,'role':'entrypoint'},
  ],
  'codeEvidence':codeEvidence,
  'rootCause':{'summary':'The violated invariant is that a user may only overwrite files inside their own workspace. The overwrite_original branch enforces that invariant exclusively for studio/ paths via canReadStudioMediaPath, then resolves the write target with classifyMediaReference(input.sourcePath) passing no userId or workspace, so non-studio paths resolve against the shared legacy workspace root that is not isolated per tenant. The subsequent fs.writeFile(ref.absolutePath, buffer) therefore writes outside the caller workspace.','evidenceRefs':['service-sig','overwrite-branch','classify','shared-root']},
  'remediation':'Before writing, resolve sourcePath through the workspace-scoped path resolver using the caller StudioScope/userId and reject paths whose resolved absolutePath is not inside the caller workspace root. Apply the same canRead/ownership check used for studio/ paths to workspace_relative, workspace_absolute, and user_upload kinds; do not call classifyMediaReference without the user/workspace context on a write path.',
  'remediationTests':'Add a test that an authenticated user in workspace A cannot overwrite a file under the shared workspace root owned by workspace B via action=overwrite_original with a workspace_relative sourcePath; assert a 403/400 and that the target file is unchanged.',
  'preventiveControls':'Resolve all overwrite targets with requirePathInside against the caller workspace root and enforce workspace ownership before any fs.writeFile; prefer the workspace-scoped writeFile helper over raw fs.writeFile.',
  'validation':{'method':'static source trace','summary':'The trace shows the guard at line 617 is conditioned on sourcePath.startsWith(studio/), classifyMediaReference at line 620 receives no scope, the shared root is confirmed in getWorkspacePath, and the save route forwards the full body with only caller-workspace canWrite.','evidenceRefs':['overwrite-branch','classify','shared-root','save-route'],'assertions':['The workspace readability guard is skipped for non-studio source paths.','classifyMediaReference is called without userId, resolving workspace-relative paths to the shared root.','fs.writeFile writes the resolved path with no per-workspace ownership check.'],'limitations':['No live HTTP reproduction was run; victim-file population in the shared root is deployment-dependent.']},
  'attackPath':{'summary':'An authenticated user with canWrite to their own workspace POSTs overwrite_original with a valid in-workspace previewPath and a non-studio sourcePath pointing at a file in the shared workspace root; the studio/ guard is bypassed and the file is overwritten with the caller edited image.','dataflow':{'summary':'sourcePath -> saveAspectRatioEdit -> applyAspectRatioEdit overwrite_original -> classifyMediaReference (no scope) -> resolveValidatedWorkspaceRelativePath -> getWorkspacePath shared root -> fs.writeFile(ref.absolutePath, buffer).','source':'caller-controlled sourcePath in the request body','sink':'fs.writeFile(ref.absolutePath, buffer)','outcome':'a file in the shared workspace root is overwritten with attacker-controlled image content','evidenceRefs':['overwrite-branch','classify','shared-root']},'reachability':{'summary':'Requires an authenticated session with canWrite to an own workspace and a victim relative path under the shared workspace root; the studio/ scope guard is bypassed because sourcePath does not start with studio/.','attacker':'authenticated tenant user','entrypoint':'POST /api/studio/aspect-ratio/save','outcome':'cross-user/cross-tenant file overwrite or destruction'},'evidenceRefs':['overwrite-branch','classify','shared-root'],'impact':{'level':'high','why':'Files belonging to other users/workspaces in the shared workspace root can be overwritten or destroyed, breaking cross-tenant integrity and availability.'},'likelihood':{'level':'medium','why':'Requires authentication, canWrite to an own workspace, and knowledge of a victim relative path, which may be enumerable in the shared root.'},'limitations':['Written bytes are a sharp re-encoded image, not arbitrary content; writes stay inside the shared root.']},
  'provenance':{'source':'local_plugin'},
  'extensions':{}
}

findings={'documentType':'codex-security.findings','schemaVersion':'1.0','scanId':SCAN_ID,'findings':[finding]}
with open(os.path.join(SCAN,'findings.json'),'w',encoding='utf-8') as f:
    json.dump(findings,f,indent=2,ensure_ascii=False)
    f.write('\n')

manifest={
  'documentType':'codex-security.scan-manifest',
  'schemaVersion':'1.0',
  'scan':{
    'id':SCAN_ID,
    'producer':{'name':'codex-security-plugin','version':'0.1.14'},
    'status':'completed',
    'startedAt':'2026-07-29T13:20:00Z',
    'completedAt':'2026-07-29T13:55:00Z',
    'target':{'kind':'git_worktree','targetId':TARGET_ID,'displayName':DISPLAY,'remote':REMOTE,'revision':REV,'snapshotDigest':SNAP},
    'scope':{'summary':'Standard single-pass security audit of the MCP integration layer and Studio integrations: 50 files under app/api/integrations, app/lib/integrations, and app/lib/mcp.','includePaths':['app/api/integrations/','app/lib/integrations/','app/lib/mcp/'],'excludePaths':[]},
    'threatModel':{'summary':'Multi-tenant Next.js app with per-user/org secrets, MCP proxying/OAuth, and Studio media generation; primary risk is workspace/tenant isolation and server-side fetch safety.','assets':['per-user/org secrets and API keys','MCP config and OAuth credentials/state','Studio media assets/outputs/edits','shared legacy workspace root','control-plane instance token'],'trustBoundaries':['authenticated HTTP request to API route','user-controlled request bodies','server to external providers and MCP servers','server to control plane','per-workspace storage vs shared legacy root'],'attackerCapabilities':['authenticated low-privilege tenant user with canWrite','controls request bodies and media reference paths/URLs'],'securityObjectives':['workspace/tenant isolation for file reads/writes','SSRF prevention','path traversal prevention','secret protection','MCP config validation and stdio gating'],'assumptions':['safe-paths and safe-external-fetch are trusted primitives','multi-tenant deployments share the legacy data/workspace root']},
    'coverageRef':'coverage.json',
    'findingsRef':'findings.json',
  }
}
with open(os.path.join(SCAN,'scan-manifest.json'),'w',encoding='utf-8') as f:
    json.dump(manifest,f,indent=2,ensure_ascii=False)
    f.write('\n')

coverage={
  'documentType':'codex-security.coverage',
  'schemaVersion':'1.0',
  'scanId':SCAN_ID,
  'mode':'scoped_path',
  'completeness':'complete',
  'inventoryStrategy':'scoped_path',
  'includePaths':['app/api/integrations/','app/lib/integrations/','app/lib/mcp/'],
  'excludePaths':[],
  'surfaces':[
    {'id':'surface_studio_aspect_ratio_save','label':'Studio aspect-ratio save (overwrite_original)','disposition':'reported','receiptRefs':['artifacts/02_discovery/candidate_ledger.jsonl'],'riskArea':'Path traversal / authorization on file write','notes':'overwrite_original skips the workspace scope check for non-studio source paths and writes to the shared legacy workspace root.'},
    {'id':'surface_mcp_manager','label':'MCP server manager (stdio/http transport)','disposition':'no_issue_found','receiptRefs':['artifacts/02_discovery/candidate_ledger.jsonl'],'riskArea':'Command execution / SSRF','notes':'stdio gated behind MCP_ALLOW_STDIO; http URLs validated by assertMcpHttpUrlAllowed; env expansion uses configured values only.'},
    {'id':'surface_mcp_oauth','label':'MCP OAuth flow and token storage','disposition':'no_issue_found','receiptRefs':[],'riskArea':'OAuth state/PKCE and secret storage','notes':'PKCE S256, random state, expiry, token files 0o600; discovery URLs pass network-policy; clientSecret rejected in config.'},
    {'id':'surface_mcp_network_policy','label':'MCP network policy and safe-external-fetch','disposition':'no_issue_found','receiptRefs':[],'riskArea':'SSRF','notes':'Blocks private/local IPs, localhost, non-standard ports, embedded credentials; re-validates after redirects.'},
    {'id':'surface_env_secrets','label':'Env/secret storage and env API route','disposition':'no_issue_found','receiptRefs':[],'riskArea':'Secret handling / authorization','notes':'AES-256-GCM at rest; user/org/system scopes enforced via session and admin/org-admin checks; key format validated.'},
    {'id':'surface_mcp_config','label':'MCP config validation and storage','disposition':'no_issue_found','receiptRefs':[],'riskArea':'Config injection / path traversal','notes':'parseAndValidateMcpConfig rejects secret literals and validates env keys; storage confined by requirePathInside.'},
    {'id':'surface_media_reference','label':'Media reference resolution and provider fetches','disposition':'no_issue_found','receiptRefs':[],'riskArea':'SSRF / path traversal','notes':'Local paths confined by resolvePathInside; external URLs via fetchExternalResourceSafely; workspace-scoped refs checked for canRead.'},
    {'id':'surface_generation_services','label':'Studio generation/provider services (Veo, Seedance, image, sound, transcription)','disposition':'no_issue_found','receiptRefs':[],'riskArea':'SSRF / credential handling','notes':'Provider endpoints are hardcoded; result/download URLs come from trusted provider responses; outputs written via confined writeOutputFile.'},
    {'id':'surface_studio_crud','label':'Studio persona/style/product/preset/markup/usage/bulk services','disposition':'no_issue_found','receiptRefs':[],'riskArea':'Authorization / file access','notes':'Asset reads/writes confined by requireStudioFilePath; preset ownership enforced; reference paths guarded by assertStudioReferenceReadable.'},
  ],
  'explicitExclusions':[],
  'deferred':[],
  'openQuestions':[{'question':'Confirm whether production deployments store victim files in the shared legacy data/workspace root; if not, the aspect-ratio overwrite severity may drop to medium.','followUpPrompt':'Review commits touching app/lib/utils/workspace-manager.ts getWorkspacePath and app/lib/filesystem/workspace-files.ts to confirm whether the shared legacy root holds cross-user files in multi-tenant production.'}]
}
with open(os.path.join(SCAN,'coverage.json'),'w',encoding='utf-8') as f:
    json.dump(coverage,f,indent=2,ensure_ascii=False)
    f.write('\n')
print('wrote findings.json, scan-manifest.json, coverage.json')
