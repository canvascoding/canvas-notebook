# Threat Model — Studio Media & References (Scoped Path Scan)

## Summary

Canvas Notebook exposes a set of authenticated Next.js App Router endpoints under
`app/api/studio/**` and `app/api/files/preview` that read, list, upload, transform, and
serve user media (images/video/audio) and HTML previews from a workspace-scoped on-disk
storage tree rooted at the Canvas data directory. The reviewed scope covers the studio
media, references, aspect-ratio, and file-preview API routes plus the integration
libraries that resolve, authorize, and read those files.

## Assets

- User-uploaded reference images / video / audio stored under per-workspace Studio asset,
  output, and edit trees (`<data-root>/studio/organizations/<org>/workspaces/<ws>/...`)
  and the legacy shared `<data-root>/user-uploads/studio-references/` directory.
- Generated Studio outputs and edits owned by a workspace.
- System preset previews under `<data-root>/studio/system/assets/presets/` (shared).
- The Canvas data root boundary: cross-workspace / cross-organization isolation must hold.

## Trust Boundaries

- Unauthenticated internet caller -> authenticated session (better-auth `auth.api.getSession`).
- Authenticated caller -> resolved workspace scope (`requireStudioRequestScope` /
  `requireRequestWorkspace`); workspace membership and `canRead`/`canWrite` permissions
  gate access.
- Caller-controlled path strings (URL path segments, query `path`, JSON `sourcePath`/
  `previewPath`/`url`) -> filesystem reads/writes and outbound HTTP fetches.
- Per-workspace storage isolation: a caller scoped to workspace A must not read or
  overwrite workspace B's files.

## Attacker Capabilities

- Any authenticated user with a valid workspace scope can call the reviewed routes.
- The attacker fully controls path-shaped inputs: the `[id]` segment of
  `/api/studio/references/[id]`, the catch-all `[...path]` of the media/media-preview
  routes, the `?path=` query of `/api/files/preview`, and JSON body fields
  (`sourcePath`, `previewPath`, `url`, `targetDirectory`, `fileName`).
- The attacker may submit encoded path segments and attempt traversal sequences.

## Security Objectives

- Path containment: every caller-controlled path must resolve and stay inside the
  caller's authorized storage root; no cross-workspace or data-root escape.
- Authorization: each file read/write must be bound to the caller's workspace scope and
  pass the corresponding `canRead*`/visibility check.
- SSRF containment: user-supplied remote URLs must be resolved/validated before fetch.
- Active-content safety: HTML/JS/SVG served from storage must not execute in the victim's
  origin context (forced download or sandboxed preview CSP).

## Assumptions

- The on-disk storage roots and the data root are not directly exposed beyond these
  routes; the routes are the trust boundary.
- `resolvePathInside` / `isPathInside` (lexicographic containment with `path.resolve`)
  is the authoritative containment primitive and is trusted.
- Reference asset filenames are server-generated random UUIDs (`ref-<uuid>.<ext>`).
- Next.js App Router supplies decoded dynamic-segment values to route handlers; whether
  encoded `%2F` survives as a literal `/` inside a single `[id]` segment is a runtime
  fact outside the reviewed source.

Repository: target_sha256_adf3597ca7dd0df024ba0592e6eee123616bef77fb6ae1f5965f11b984a4cffa
