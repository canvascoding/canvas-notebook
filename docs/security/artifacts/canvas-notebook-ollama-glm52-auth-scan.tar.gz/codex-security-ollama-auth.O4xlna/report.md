# Security Review: canvasstudios-notebook

## Scope

Scoped single-pass security review of authentication, authorization, session handling, license gate, WebSocket auth, workspace path/permission enforcement, database layer, and security helper modules.

- Scan mode: scoped_path
- Target kind: git_worktree
- Target ID: target_sha256_adf3597ca7dd0df024ba0592e6eee123616bef77fb6ae1f5965f11b984a4cffa
- Revision: b18eab5234e84d699a105acbad979714a87a7f70
- Snapshot digest: codex-security-snapshot/v1:sha256:f233c6c3dec3cd1369f3a22361b5fcd91e1096d797358145a0c632c768118e76
- Inventory strategy: scoped_path
- Included paths: app/api/auth, app/api/account, app/api/setup, app/api/license, app/lib/auth.ts, app/lib/security, app/lib/workspaces, app/lib/db, server/websocket-auth.ts, server/websocket-server.ts, server/websocket-session-queue.ts, server/websocket-rate-limit.ts, proxy.ts
- Excluded paths: none
- Runtime or test status: not recorded
- Artifacts reviewed: artifacts/01_context/threat_model.md, artifacts/02_discovery/in_scope_files.txt, artifacts/02_discovery/rank_input.jsonl, artifacts/02_discovery/candidate_ledger.jsonl

Limitations and exclusions:
- Out-of-scope route handlers referenced by open questions were not reviewed.
- better-auth and third-party library internals were not reviewed.
- Excluded .git/\*\*: Git internals excluded from review.

### Scan Summary

| Field | Value |
| --- | --- |
| Reportable DSS findings | 1 |
| Report instances | 1 |
| Report severity mix | medium: 1 |
| Report confidence mix | high: 1 |
| Coverage | complete |
| Validation mode | compact standard-scan validation and attack-path analysis |

Canonical artifacts: `scan-manifest.json`, `findings.json`, and `coverage.json`. This report is a deterministic projection of those files.

## Threat Model

Scoped threat model for the Canvas Notebook auth/security surface: assets, trust boundaries, attacker capabilities, objectives, and assumptions are recorded in artifacts/01_context/threat_model.md.

### Assets

- User accounts, sessions, credentials
- Owner/admin roles and bootstrap state
- License gate signing key
- Workspace files and brand assets
- WebSocket chat sessions

### Trust Boundaries

- Browser vs middleware/API
- WebSocket client vs WS server
- Mobile app vs server
- Server vs internal license endpoint
- Server vs filesystem
- Server vs external HTTP

### Attacker Capabilities

- Unauthenticated network attacker
- Authenticated low-privilege user
- Repository knowledge
- Missing/weak deployment config

### Security Objectives

- Unforgeable sessions
- No license-gate bypass
- Workspace path containment
- WS session ownership
- No SSRF/injection/traversal
- No hardcoded production secrets

### Assumptions

- Operators set BETTER_AUTH_SECRET in production
- Reverse proxies set x-forwarded-proto honestly
- Out-of-scope mobile handlers enforce ticket validation

## Findings

| Findings | Reports | Severity | Confidence | Detailed write-up |
| --- | --- | --- | --- | --- |
| Hardcoded fallback secret signs session and license-gate cookies when BETTER_AUTH_SECRET is unset | [occ_818e94823a5d0b418aafad9c](#finding-1) | medium | high | occ_818e94823a5d0b418aafad9c: inline below |

### Confidence Scale

| Label | Meaning |
| --- | --- |
| high | Direct evidence supports the finding with no material unresolved blocker. |
| medium | Evidence supports a plausible issue, but material runtime or reachability proof remains. |
| low | Evidence is incomplete and the item is retained only for explicit follow-up. |

<a id="finding-1"></a>

### [1] Hardcoded fallback secret signs session and license-gate cookies when BETTER_AUTH_SECRET is unset

| Field | Value |
| --- | --- |
| Severity | medium |
| Confidence | high |
| Confidence rationale | The fallback constant is verifiable in the public source and is selected unconditionally when both BETTER_AUTH_SECRET and AUTH_SECRET are unset; no production guard rejects it. |
| Category | hardcoded-credentials |
| CWE | CWE-321, CWE-798 |
| Affected lines | app/lib/auth.ts:14-16, proxy.ts:123-125 |

#### Summary

The Better Auth signing secret and the license-gate HMAC key fall back to the hardcoded constant canvas-notebook-local-dev-secret-change-me when BETTER_AUTH_SECRET and AUTH_SECRET are both unset. There is no production guard that refuses to start with the default, so a deployment that forgets to set the secret signs session cookies and license-gate cookies with a publicly known key.

#### Root Cause

The invariant is that session and license-gate signing keys must be unpredictable and unique per deployment. Startup enforces no such invariant: when BETTER_AUTH_SECRET and AUTH_SECRET are both absent, auth.ts and proxy.ts silently select a constant committed to the public repository, with no production guard that rejects the default.

**Better Auth secret fallback** — `app/lib/auth.ts:14-16`

authSecret is passed as betterAuth({ secret: authSecret }) so session tokens are signed with this value when neither env var is set.

```typescript
const authSecret =
  process.env.BETTER_AUTH_SECRET ||
  process.env.AUTH_SECRET ||
  "canvas-notebook-local-dev-secret-change-me";
```

**License-gate HMAC key fallback** — `proxy.ts:123-125`

getSecret() feeds sign(), which HMACs the canvas_license_gate cookie payload used by hasValidLicenseGateCookie and buildLicenseGateCookie.

```typescript
function getSecret(): string {
  return process.env.BETTER_AUTH_SECRET || process.env.AUTH_SECRET || "canvas-notebook-local-dev-secret-change-me";
}
```

#### Validation

The fallback constant is verifiable in the public source and is selected unconditionally when both BETTER_AUTH_SECRET and AUTH_SECRET are unset; no production guard rejects it. Validation details were not recorded separately.

Validation method: static review and config trace

#### Dataflow

The canonical finding records the affected path at app/lib/auth.ts:14-16, proxy.ts:123-125, but no expanded source-to-sink narrative was recorded.

#### Reachability

Reachability was not recorded beyond the canonical finding summary and affected locations.

#### Severity

**Medium** — Authentication bypass and license-gate bypass are high-impact, but exploitation is conditional on operator misconfiguration (missing secret), lowering likelihood to medium and net severity to medium.

Setting BETTER_AUTH_SECRET/AUTH_SECRET to a strong random value removes the fallback; adding a production startup guard that refuses the default value would close the misconfiguration path.

#### Remediation

Require a strong operator-provided BETTER_AUTH_SECRET (or AUTH_SECRET) and fail startup in production (NODE_ENV=production) when it is missing or equal to the default constant. Generate a random secret on first run if one is not configured for local development only.

Tests:
- Assert the server refuses to boot in production with the default secret.
- Assert a configured BETTER_AUTH_SECRET is used for both better-auth and the license-gate HMAC.
- Assert a forged cookie signed with the default constant is rejected when a custom secret is set.

Preventive controls:
- Startup configuration validation that rejects known-weak/default secrets in production.
- Separate the license-gate HMAC key from the better-auth session secret.

## Reviewed Surfaces

| Surface | Risk Area | Outcome | Notes |
| --- | --- | --- | --- |
| Auth session signing secret | Authentication / credential management | Reported | Hardcoded fallback secret reported (candidate-31aa2755d78219eb). Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| License gate cookie HMAC | License enforcement | Reported | License-gate HMAC reuses the same fallback secret; covered by the reported finding. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Middleware route authorization | Authorization | No issue found | isPublicRoute substring match reviewed; no concrete bypass in scoped surface (candidate-dffb3d2a5f3f711d suppressed). Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| WebSocket authentication and authorization | Authentication / authorization | No issue found | Origin check, session validation, session-ownership checks, rate limits, and message size limits verified. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Workspace path containment | Path traversal | No issue found | path-guard.ts traversal protection verified (candidate-4371f429a2a3fb38 suppressed). Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Workspace permissions and request gating | Authorization | No issue found | requireSessionWorkspace/requireRequestWorkspace enforce session and workspace permissions. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Database query construction | SQL injection | No issue found | Parameterized queries and identifier quoting verified (candidate-0269e633d8fec260 suppressed). Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| External HTTP fetch SSRF guard | SSRF | No issue found | safe-external-fetch.ts per-hop validation verified (candidate-d041521f04f17bed suppressed). Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Account email change | Account takeover | No issue found | Password re-verification, duplicate-email check, and session invalidation present. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Initial owner setup | Bootstrap / privilege | No issue found | Rate-limited; createInitialOwner rejects ALREADY_CONFIGURED; no auth required by design for first owner. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| License API routes | License enforcement | No issue found | activate/register require session; status is public by design; activationPath open-redirect mitigated by allowlist to /settings?tab=license. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Brand logo/profile upload | File upload / XSS | No issue found | Magic-byte type validation, sharp pixel/size limits, hex-color and length validation, workspace-path containment. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Trusted origin configuration | CSRF / origin validation | No issue found | Origins normalized; localhost only added outside production; mobile protocols allowlisted. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |
| Environment variable allowlist | Secret exposure | No issue found | filterSafeEnv blocks KEY/TOKEN/SECRET/PASSWORD/provider/DATABASE patterns. Evidence: artifacts/02_discovery/candidate_ledger.jsonl |

## Open Questions And Follow Up

- The middleware allows /api/automations/execute and /api/automations/scheduler without a session cookie. Do those handlers enforce authentication and authorization independently?
  - Follow-up prompt: Review app/api/automations/execute/route.ts and app/api/automations/scheduler/route.ts for unauthenticated automation execution or privilege escalation.
- The middleware skips auth for mobile HTML preview routes relying on an opaque ticket. Does the html-preview route handler validate the ticket and workspace scope?
  - Follow-up prompt: Review app/api/mobile/v1/files/html-preview/route.ts and app/lib/mobile/html-preview-ticket.ts for ticket validation, expiry, and workspace scope checks.
- WebSocket mobile auth uses consumeMobileChatTicket. Are mobile chat tickets single-use, short-lived, and bound to a user/workspace?
  - Follow-up prompt: Review app/lib/mobile/ws-ticket.ts for ticket issuance, consumption, expiry, and replay protection.
- account/email calls auth.api.verifyPassword with headers and only a password body. Does better-auth verify the password against the authenticated session user?
  - Follow-up prompt: Confirm better-auth verifyPassword semantics so an authenticated attacker cannot change email without knowing the current password.
