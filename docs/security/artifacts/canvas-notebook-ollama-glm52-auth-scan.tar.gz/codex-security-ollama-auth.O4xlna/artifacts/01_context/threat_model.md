# Threat Model — Canvas Notebook Auth & Security Surface

## Summary

Canvas Notebook is a self-hosted, Next.js-based notebook/AI application with
better-auth email/password authentication, a custom license gate, WebSocket chat
runtime, multi-workspace file access, and optional Postgres/SQLite storage. This
scoped scan reviews the authentication, authorization, session handling, license
gate, WebSocket auth, workspace path/permission enforcement, database layer, and
security helper modules.

## Assets

- User accounts, session cookies, and credentials (better-auth user/session).
- Owner/admin role assignments and bootstrap initial-owner state.
- License gate state and the HMAC key that signs the canvas_license_gate cookie.
- Workspace files under /data and per-workspace brand assets.
- WebSocket chat sessions and runtime control channels.
- Integration/AI provider API keys and bootstrap credentials (protected by the
  env-allowlist and secret fallback reviewed here).

## Trust Boundaries

- Browser/client vs Next.js middleware (proxy.ts) and API routes.
- WebSocket client vs WebSocket server upgrade (/ws/chat).
- Mobile app vs server (mobile ticket + trusted mobile protocol origins).
- Server vs internal license status endpoint (/api/license/status).
- Server vs filesystem workspace roots (path-guard.ts).
- Server vs external HTTP resources (safe-external-fetch.ts).

## Attacker Capabilities

- Unauthenticated network attacker who can send HTTP/WS requests and control
  headers (Origin, x-forwarded-proto, cookies).
- Authenticated low-privilege user who can call authenticated API/WS endpoints.
- Attacker with knowledge of the public source repository (knows default values).
- Attacker who controls a deployed instance missing or weak configuration.

## Security Objectives

- Authentication required for all non-public routes; sessions unforgeable.
- License gate cannot be bypassed without a valid signed cookie or license.
- Workspace file access confined to the user authorized workspace root.
- WebSocket actions confined to sessions the user owns.
- No SSRF, command injection, SQL injection, or path traversal in scope.
- No hardcoded production-usable secrets.

## Assumptions

- better-auth correctly signs/verifies session cookies using the configured
  secret; operators are expected to set BETTER_AUTH_SECRET/AUTH_SECRET.
- Reverse proxies set x-forwarded-proto honestly; the license status URL is
  same-origin.
- Mobile HTML preview and mobile WebSocket ticket handlers (out of scope) enforce
  their own ticket validation and workspace scope.

Repository: target_sha256_adf3597ca7dd0df024ba0592e6eee123616bef77fb6ae1f5965f11b984a4cffa
Version: b18eab5234e84d699a105acbad979714a87a7f70
