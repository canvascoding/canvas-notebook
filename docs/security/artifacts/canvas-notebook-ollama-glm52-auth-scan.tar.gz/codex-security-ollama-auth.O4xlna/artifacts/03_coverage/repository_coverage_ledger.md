# Repository Coverage Ledger

Scan ID: 05071376-b541-4a65-94fa-1d746f1fdb33
Mode: scoped_path | Completeness: complete

## Reviewed surfaces

| Surface | Risk Area | Outcome | Notes |
| --- | --- | --- | --- |
| Auth session signing secret | Authentication / credentials | Reported | Hardcoded fallback secret (CWE-798/321). |
| License gate cookie HMAC | License enforcement | Reported | Reuses the same fallback secret. |
| Middleware route authorization | Authorization | No issue found | isPublicRoute substring match reviewed; no concrete bypass. |
| WebSocket authn/authz | Authentication / authorization | No issue found | Origin check, session validation, ownership, rate limits verified. |
| Workspace path containment | Path traversal | No issue found | path-guard.ts traversal protection verified. |
| Workspace permissions/request gating | Authorization | No issue found | Session + workspace permission enforcement verified. |
| Database query construction | SQL injection | No issue found | Parameterized queries + identifier quoting verified. |
| External HTTP fetch SSRF guard | SSRF | No issue found | Per-hop validation against private/local ranges verified. |
| Account email change | Account takeover | No issue found | Password re-verification, duplicate check, session invalidation. |
| Initial owner setup | Bootstrap / privilege | No issue found | Rate-limited; ALREADY_CONFIGURED guard. |
| License API routes | License enforcement | No issue found | activate/register require session; activationPath open-redirect mitigated. |
| Brand logo/profile upload | File upload / XSS | No issue found | Magic-byte validation, sharp limits, hex/length validation, path containment. |
| Trusted origin configuration | CSRF / origin validation | No issue found | Origin normalization; localhost only outside production. |
| Environment variable allowlist | Secret exposure | No issue found | KEY/TOKEN/SECRET/PASSWORD/provider/DATABASE patterns blocked. |

## Suppressed candidates

- candidate-dffb3d2a5f3f711d (CWE-285, proxy.ts): unanchored /api/auth/ substring match; no concrete bypass in scoped surface.
- candidate-4371f429a2a3fb38 (CWE-22, path-guard.ts): traversal protection verified.
- candidate-0269e633d8fec260 (CWE-89, db layer): parameterized queries and quoting verified.
- candidate-d041521f04f17bed (CWE-918, safe-external-fetch.ts): SSRF guard verified.
