# Threat Model — canvasstudios-notebook (agents & automations)

## Scope
Standard single-pass security scan of the in-scope Next.js App Router API routes and server libraries under app/api/agents, app/api/automations, app/lib/agents, and app/lib/automations. These surfaces expose agent management, agent file editing, agent access/member/grant management, browser runtime controls, tool configuration, automation job CRUD, automation scheduling, webhook triggers, automation run execution, and automation run/log viewing.

## Assets
- User and organization data: agent profiles, managed agent files (AGENTS.md, USER.md, MEMORY.md, SOUL.md, TOOLS.md, HEARTBEAT.md), agent members and grants.
- Automation jobs and runs: schedules, prompts, delivery channel configuration, run metadata, run logs, and webhook event records.
- Webhook signing secrets and internal scheduler API keys.
- Agent delete confirmation tokens (HMAC over AUTH_SECRET).
- Workspace files referenced by automation target output paths and context paths.
- Connected-app (Composio/MCP) connection metadata.

## Trust Boundaries
- Public HTTP client vs. authenticated Canvas user (better-auth session).
- Authenticated user vs. organization admin / instance admin (elevated roles).
- Canvas user vs. internal scheduler/executor (separate x-canvas-internal-token).
- External webhook caller vs. automation owner (webhook bearer secret).
- Agent execution context vs. the LLM/tool runtime (prompt-injection boundary).

## Attacker Capabilities
- Authenticate as any Canvas user and call the in-scope API routes.
- Attempt IDOR by supplying arbitrary agentId, jobId, runId, webhookId, workspaceId, organizationId, or userId path/query/body values.
- Send crafted JSON payloads to create/update automation jobs, agent files, members, grants, capability bindings, heartbeat config, and tool settings.
- Deliver arbitrary JSON bodies to active webhook endpoints (without a valid secret the request is rejected; with a leaked secret the body is attacker-controlled).
- Attempt path traversal via targetOutputPath or managed file names.
- Attempt to forge an agent-delete confirmation token.

## Security Objectives
- Every resource access is authorized against the requesting user's identity and role.
- User-controlled paths stay contained within the owning workspace.
- Secrets and tokens are verified with constant-time comparison and never disclosed.
- Webhook and internal endpoints reject unauthenticated callers.
- SQL is parameterized; no attacker-controlled string is interpolated into queries.
- Prompt construction treats external/webhook data as untrusted.

## Assumptions
- better-auth auth.api.getSession reliably authenticates the bearer session.
- Out-of-scope helpers (resolveWorkspacePath, resolveComposioContext, resolveAgentSessionWorkspaceForUser, organization permission reads) enforce the containment and membership invariants they appear to enforce; this scan records proof gaps where an in-scope caller relies on such an out-of-scope control.
- The deployment sets AUTH_SECRET/BETTER_AUTH_SECRET and CANVAS_INTERNAL_API_KEY in production; the code's hardcoded fallbacks are development-only defaults.

Repository: target_sha256_adf3597ca7dd0df024ba0592e6eee123616bef77fb6ae1f5965f11b984a4cffa
Version: a3e8e64448f3121a42e3b8fc5ad49419299b17f6
